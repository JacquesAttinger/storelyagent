import { defineConfig } from 'vite';

// https://vite.dev/config/
export default defineConfig({
	server: {
		allowedHosts: true, // Allow all hosts for cloudflared tunnel support
		host: '0.0.0.0', // Allow external connections
	},
});
